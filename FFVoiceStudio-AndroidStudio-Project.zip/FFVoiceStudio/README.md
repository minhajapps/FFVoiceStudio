# IS FF VOICE (FF Voice Studio) — TECNO KG5k Android 11 Edition

Native Kotlin + Jetpack Compose soundboard optimized for **TECNO KG5k (Android 11 / API 30)** and **Garena Free Fire**.

## Key Optimizations for TECNO KG5k (Android 11)
1. **Android 11 Compatibility**:
   - `<queries>` intent filter for `TTS_SERVICE` engine discovery on API 30.
   - `AudioFocusRequest` (`AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK`) handling ducking and transient interruptions cleanly while switching between IS FF VOICE and Free Fire.
   - `SoundboardPlaybackService` foreground media service with `MediaStyle` notification controls (`Pause/Resume`, `Stop All`).
2. **Low-Memory Tuning**:
   - Coil `MemoryCache` capped at `15%` of app heap and `16 MB` disk cache.
   - Cover images downscaled to `512px` JPEG on import.
   - `onTrimMemory()` releases idle `MediaPlayer` instances automatically; max 4 concurrent channels.
3. **Optional Floating Gaming Panel**:
   - Screen-clamped 3-column grid overlay with `>= 44dp` circular cyan Play buttons, Minimize, and Close.
   - App remains 100% functional if `SYSTEM_ALERT_WINDOW` permission is denied.
4. **Honest Voice Compatibility Diagnostic**:
   - Probes real `AudioManager` input/output devices, Bluetooth SCO/A2DP state, `activeRecordingConfigurations`, and `AudioRecord` availability.
   - Explicitly reports that direct Free Fire microphone injection is unsupported on standard Android 11 without bypassing OS security.

---

## Build Debug APK & Test on TECNO KG5k

### 1. Build Debug APK
Open this folder in **Android Studio Ladybug+** (or run in terminal with Android SDK installed):
```bash
./gradlew assembleDebug
```
Output APK path:
`app/build/outputs/apk/debug/app-debug.apk`

### 2. Install on TECNO KG5k via USB / ADB
1. On your **TECNO KG5k**, go to **Settings → My Phone** and tap **Build Number** 7 times to enable Developer Options.
2. Open **Settings → System → Developer options** and enable **USB debugging**.
3. Connect the phone via USB and run:
   ```bash
   adb devices
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
   *(Or transfer `app-debug.apk` to your phone's Downloads folder and install it via the Files app.)*

### 3. Verify on Device (TECNO KG5k + Free Fire)
1. **Background Playback & Notification Controls**: Play a sound card, switch to **Garena Free Fire**, pull down the notification shade, and verify **Pause / Resume** and **Stop All** controls work without stopping unexpectedly.
2. **Floating Panel**: Open **Settings → Floating Soundboard**, grant **Display over other apps**, drag the panel across screen edges (verifying it stays within bounds), and test Minimize/Close and 3-column Play buttons.
3. **Voice Compatibility Test**: Open the **Test** tab, tap **TEST VOICE COMPATIBILITY**, and verify it prints your TECNO KG5k Android 11 input/output devices, Bluetooth state, and the Android 11 microphone-routing notice.
4. **HiOS Battery Note (TECNO KG5k)**: If HiOS aggressive power saving closes background playback while gaming, set **IS FF VOICE** to **Don't optimize** under *Settings → Battery → App battery management*.
