# Preserve Room entities & DataStore models
-keepclassmembers class * extends androidx.room.RoomDatabase { *; }
-keep class com.ffvoicestudio.app.data.model.** { *; }

# Keep Android Media & TTS callbacks
-keepclassmembers class com.ffvoicestudio.app.tts.** { *; }
-keepclassmembers class com.ffvoicestudio.app.overlay.** { *; }
