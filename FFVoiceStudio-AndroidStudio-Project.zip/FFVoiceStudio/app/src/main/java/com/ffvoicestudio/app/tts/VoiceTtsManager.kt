package com.ffvoicestudio.app.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

class VoiceTtsManager(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _voices = MutableStateFlow<List<Voice>>(emptyList())
    val voices: StateFlow<List<Voice>> = _voices.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engine = tts ?: return
            val available = engine.voices
                ?.filter { it.locale.language in setOf("en", "bn") }
                ?.sortedWith(compareBy({ it.locale.language }, { it.name }))
                ?: emptyList()
            _voices.value = available
            _isReady.value = true
        }
    }

    fun preview(text: String, voice: Voice?, pitch: Float, speechRate: Float) {
        val engine = tts ?: return
        if (!_isReady.value || text.isBlank()) return
        voice?.let { engine.voice = it } ?: run { engine.language = Locale.US }
        engine.setPitch(pitch.coerceIn(0.5f, 1.8f))
        engine.setSpeechRate(speechRate.coerceIn(0.5f, 1.8f))
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { _isSpeaking.value = true }
            override fun onDone(utteranceId: String?) { _isSpeaking.value = false }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { _isSpeaking.value = false }
        })
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preview_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    suspend fun synthesizeToWav(
        text: String,
        voice: Voice?,
        pitch: Float,
        speechRate: Float,
        outputDir: File
    ): Result<File> = suspendCancellableCoroutine { cont ->
        val engine = tts
        if (engine == null || !_isReady.value) {
            cont.resume(Result.failure(IllegalStateException("TTS engine not initialized")))
            return@suspendCancellableCoroutine
        }

        val outFile = File(outputDir, "${UUID.randomUUID()}.wav")
        val utteranceId = "tts_${UUID.randomUUID()}"

        voice?.let { engine.voice = it }
        engine.setPitch(pitch.coerceIn(0.5f, 1.8f))
        engine.setSpeechRate(speechRate.coerceIn(0.5f, 1.8f))

        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == utteranceId && cont.isActive) {
                    cont.resume(Result.success(outFile))
                }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                if (id == utteranceId && cont.isActive) {
                    outFile.delete()
                    cont.resume(Result.failure(RuntimeException("TTS synthesis failed")))
                }
            }
        })

        val params = Bundle()
        val result = engine.synthesizeToFile(text, params, outFile, utteranceId)
        if (result != TextToSpeech.SUCCESS && cont.isActive) {
            cont.resume(Result.failure(RuntimeException("Unable to queue TTS synthesis")))
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
