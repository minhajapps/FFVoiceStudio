package com.ffvoicestudio.app.media

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import com.ffvoicestudio.app.data.model.VoiceCard
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

data class SoundTrackStatus(
    val cardId: String,
    val cardName: String,
    val isPlaying: Boolean,
    val progress: Float
)

data class PlaybackState(
    val activeTracks: Map<String, SoundTrackStatus> = emptyMap(),
    val primaryCardId: String? = null,
    val isAnyPlaying: Boolean = false,
    val masterVolume: Float = 1.0f,
    val focusState: String = "Idle",
    val error: String? = null
) {
    val activeCardId: String? get() = primaryCardId
    val isPlaying: Boolean get() = isAnyPlaying
    val progress: Float get() = primaryCardId?.let { activeTracks[it]?.progress } ?: 0f
}

/**
 * Stable Android 11 soundboard playback engine supporting:
 * - Multiple concurrent sound effects OR individual pause/resume/stop
 * - Master volume + per-card individual volume
 * - Proper Android AudioFocusRequest handling (ducking & transient loss while gaming)
 * - Clean MediaPlayer resource release to prevent memory leaks on TECNO KG5k
 */
class VoiceAudioPlayer(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val players = ConcurrentHashMap<String, MediaPlayer>()
    private val cardVolumes = ConcurrentHashMap<String, Float>()
    private val cardNames = ConcurrentHashMap<String, String>()

    private var progressJob: Job? = null
    private var focusRequest: AudioFocusRequest? = null
    private var pausedByTransientFocus = false
    private var masterVol = 1.0f

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()

    var onStateChangedForNotification: ((PlaybackState) -> Unit)? = null

    private val focusListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                // Permanent focus loss (e.g. another media app started): stop cleanly
                pausedByTransientFocus = false
                stopAll("Audio focus lost")
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                // Phone call or system voice prompt: pause active tracks so user can resume
                pausedByTransientFocus = _state.value.isAnyPlaying
                pauseAll("Paused (call/interruption)")
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // Lower soundboard output gently instead of stopping during game cues
                applyScaledVolumes(0.35f)
                updateState(focusLabel = "Ducked")
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                applyScaledVolumes(1.0f)
                if (pausedByTransientFocus) {
                    pausedByTransientFocus = false
                    resumeAll()
                } else {
                    updateState(focusLabel = "Active")
                }
            }
        }
    }

    fun togglePlay(card: VoiceCard) {
        val existing = players[card.id]
        if (existing != null) {
            val isPlayingNow = runCatching { existing.isPlaying }.getOrDefault(false)
            if (isPlayingNow) {
                pauseSound(card.id)
            } else {
                resumeSound(card.id)
            }
            return
        }
        playSound(card)
    }

    fun playSound(card: VoiceCard) {
        if (!requestAudioFocus()) {
            updateState(error = "Audio focus denied by system")
            return
        }

        // Release any stale player for the same card id
        stopSound(card.id, abandonIfEmpty = false)

        // Cap concurrent players to 4 to protect TECNO KG5k RAM
        if (players.size >= 4) {
            val oldestId = players.keys.firstOrNull()
            if (oldestId != null) stopSound(oldestId, abandonIfEmpty = false)
        }

        try {
            cardVolumes[card.id] = card.volume.coerceIn(0f, 1f)
            cardNames[card.id] = card.name

            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(card.audioPath)
                setOnPreparedListener { mp ->
                    val effective = (masterVol * (cardVolumes[card.id] ?: 1.0f)).coerceIn(0f, 1f)
                    mp.setVolume(effective, effective)
                    mp.start()
                    updateState(primaryCardId = card.id, focusLabel = "Active", error = null)
                    ensureProgressLoop()
                    SoundboardPlaybackService.sync(context, _state.value)
                }
                setOnCompletionListener {
                    stopSound(card.id)
                }
                setOnErrorListener { _, _, _ ->
                    stopSound(card.id)
                    updateState(error = "Playback failed for ${card.name}")
                    true
                }
                prepareAsync()
            }
            players[card.id] = player
        } catch (e: Exception) {
            stopSound(card.id)
            updateState(error = e.localizedMessage ?: "Unable to play sound")
        }
    }

    fun pauseSound(cardId: String) {
        players[cardId]?.let { mp ->
            runCatching {
                if (mp.isPlaying) mp.pause()
            }
        }
        updateState()
        SoundboardPlaybackService.sync(context, _state.value)
    }

    fun resumeSound(cardId: String) {
        if (!requestAudioFocus()) return
        players[cardId]?.let { mp ->
            runCatching { mp.start() }
            ensureProgressLoop()
        }
        updateState(primaryCardId = cardId, focusLabel = "Active")
        SoundboardPlaybackService.sync(context, _state.value)
    }

    fun pauseAll(reason: String = "Paused") {
        players.values.forEach { mp ->
            runCatching { if (mp.isPlaying) mp.pause() }
        }
        updateState(focusLabel = reason)
        SoundboardPlaybackService.sync(context, _state.value)
    }

    fun resumeAll() {
        if (players.isEmpty() || !requestAudioFocus()) return
        players.values.forEach { mp ->
            runCatching { if (!mp.isPlaying) mp.start() }
        }
        ensureProgressLoop()
        updateState(focusLabel = "Active")
        SoundboardPlaybackService.sync(context, _state.value)
    }

    fun stopSound(cardId: String, abandonIfEmpty: Boolean = true) {
        players.remove(cardId)?.let { mp ->
            runCatching { if (mp.isPlaying) mp.stop() }
            runCatching { mp.reset() }
            runCatching { mp.release() }
        }
        cardNames.remove(cardId)
        if (players.isEmpty()) {
            progressJob?.cancel()
            progressJob = null
            if (abandonIfEmpty) abandonAudioFocus()
        }
        updateState()
        SoundboardPlaybackService.sync(context, _state.value)
    }

    fun stopAll(reason: String = "Idle") {
        progressJob?.cancel()
        progressJob = null
        val keys = players.keys.toList()
        keys.forEach { id ->
            players.remove(id)?.let { mp ->
                runCatching { if (mp.isPlaying) mp.stop() }
                runCatching { mp.reset() }
                runCatching { mp.release() }
            }
        }
        cardNames.clear()
        abandonAudioFocus()
        _state.value = PlaybackState(masterVolume = masterVol, focusState = reason)
        SoundboardPlaybackService.sync(context, _state.value)
    }

    fun setMasterVolume(volume: Float) {
        masterVol = volume.coerceIn(0f, 1f)
        applyScaledVolumes(1.0f)
        updateState()
    }

    fun setCardVolume(cardId: String, volume: Float) {
        cardVolumes[cardId] = volume.coerceIn(0f, 1f)
        players[cardId]?.let { mp ->
            val effective = (masterVol * (cardVolumes[cardId] ?: 1f)).coerceIn(0f, 1f)
            runCatching { mp.setVolume(effective, effective) }
        }
    }

    fun releaseOnLowMemory() {
        val inactiveKeys = players.entries
            .filter { !runCatching { it.value.isPlaying }.getOrDefault(false) }
            .map { it.key }
        inactiveKeys.forEach { stopSound(it) }
    }

    private fun applyScaledVolumes(duckMultiplier: Float) {
        players.forEach { (id, mp) ->
            val cardVol = cardVolumes[id] ?: 1.0f
            val effective = (masterVol * cardVol * duckMultiplier).coerceIn(0f, 1f)
            runCatching { mp.setVolume(effective, effective) }
        }
    }

    private fun ensureProgressLoop() {
        if (progressJob?.isActive == true) return
        progressJob = scope.launch(Dispatchers.Main) {
            while (isActive && players.isNotEmpty()) {
                updateState()
                delay(80L)
            }
        }
    }

    private fun updateState(
        primaryCardId: String? = _state.value.primaryCardId,
        focusLabel: String = _state.value.focusState,
        error: String? = _state.value.error
    ) {
        val tracks = mutableMapOf<String, SoundTrackStatus>()
        var anyPlaying = false
        players.forEach { (id, mp) ->
            val playing = runCatching { mp.isPlaying }.getOrDefault(false)
            if (playing) anyPlaying = true
            val dur = runCatching { mp.duration }.getOrDefault(0)
            val pos = runCatching { mp.currentPosition }.getOrDefault(0)
            val ratio = if (dur > 0) (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f) else 0f
            tracks[id] = SoundTrackStatus(
                cardId = id,
                cardName = cardNames[id] ?: "Voice",
                isPlaying = playing,
                progress = ratio
            )
        }
        val resolvedPrimary = if (primaryCardId != null && tracks.containsKey(primaryCardId)) {
            primaryCardId
        } else {
            tracks.keys.firstOrNull()
        }
        val next = PlaybackState(
            activeTracks = tracks,
            primaryCardId = resolvedPrimary,
            isAnyPlaying = anyPlaying,
            masterVolume = masterVol,
            focusState = if (tracks.isEmpty() && focusLabel == "Active") "Idle" else focusLabel,
            error = error
        )
        _state.value = next
        onStateChangedForNotification?.invoke(next)
    }

    private fun requestAudioFocus(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val req = focusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener(focusListener)
                .build()
                .also { focusRequest = it }
            return audioManager.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        @Suppress("DEPRECATION")
        return audioManager.requestAudioFocus(
            focusListener,
            AudioManager.STREAM_MUSIC,
            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
        ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(focusListener)
        }
    }
}
