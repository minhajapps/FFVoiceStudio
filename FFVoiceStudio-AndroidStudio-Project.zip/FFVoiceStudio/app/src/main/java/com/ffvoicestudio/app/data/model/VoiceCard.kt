package com.ffvoicestudio.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class VoiceCategory(val labelEn: String, val labelBn: String) {
    TACTICAL("Tactical", "ট্যাকটিক্যাল"),
    CALLOUTS("Callouts", "কলআউট"),
    VICTORY("Victory", "বিজয়"),
    MEMES("Memes", "মিম"),
    CUSTOM("Custom", "কাস্টম")
}

@Entity(tableName = "voice_cards")
data class VoiceCard(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String = VoiceCategory.TACTICAL.name,
    val audioPath: String,
    val imagePath: String? = null,
    val durationMs: Long = 0L,
    val volume: Float = 1.0f,
    val isFavorite: Boolean = false,
    val isPinnedToOverlay: Boolean = false,
    val sourceType: String = "AUDIO", // AUDIO, VIDEO_EXTRACTED, TTS
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
