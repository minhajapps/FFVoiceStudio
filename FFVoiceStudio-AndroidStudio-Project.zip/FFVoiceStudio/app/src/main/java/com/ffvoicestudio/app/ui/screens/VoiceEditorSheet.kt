package com.ffvoicestudio.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.ffvoicestudio.app.data.model.VoiceCard
import com.ffvoicestudio.app.data.model.VoiceCategory
import com.ffvoicestudio.app.ui.theme.NeonCyan

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceEditorSheet(
    editingCard: VoiceCard?,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        category: VoiceCategory,
        audioUri: Uri?,
        videoUri: Uri?,
        imageUri: Uri?,
        isFavorite: Boolean,
        isPinned: Boolean
    ) -> Unit
) {
    var name by remember(editingCard) { mutableStateOf(editingCard?.name ?: "") }
    var category by remember(editingCard) {
        mutableStateOf(
            VoiceCategory.entries.firstOrNull { it.name == editingCard?.category }
                ?: VoiceCategory.TACTICAL
        )
    }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var isFavorite by remember(editingCard) { mutableStateOf(editingCard?.isFavorite ?: false) }
    var isPinned by remember(editingCard) { mutableStateOf(editingCard?.isPinnedToOverlay ?: false) }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            audioUri = uri
            videoUri = null
        }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            videoUri = uri
            audioUri = null
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) imageUri = uri
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (editingCard == null) "Create Voice Card" else "Edit Voice Card",
                style = MaterialTheme.typography.titleLarge
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Voice Card Name") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Text("Category", style = MaterialTheme.typography.labelMedium)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                VoiceCategory.entries.take(4).forEach { cat ->
                    FilterChip(
                        selected = category == cat,
                        onClick = { category = cat },
                        label = { Text(cat.labelEn, maxLines = 1) }
                    )
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { audioPicker.launch(arrayOf("audio/*")) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.AudioFile, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (audioUri != null) "Audio Ready" else "Add Audio")
                }

                OutlinedButton(
                    onClick = { videoPicker.launch(arrayOf("video/*")) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.VideoFile, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (videoUri != null) "Extract Video" else "Video Audio")
                }
            }

            OutlinedButton(
                onClick = { imagePicker.launch(arrayOf("image/*")) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Rounded.Image, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (imageUri != null) "Custom Cover Selected" else "Add Custom Image")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Add to Favorites")
                Switch(checked = isFavorite, onCheckedChange = { isFavorite = it })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Pin to Floating Soundboard")
                Switch(checked = isPinned, onCheckedChange = { isPinned = it })
            }

            Button(
                onClick = {
                    onSave(name, category, audioUri, videoUri, imageUri, isFavorite, isPinned)
                },
                enabled = name.isNotBlank() && (editingCard != null || audioUri != null || videoUri != null),
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color(0xFF04101A)),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Save Voice Card")
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
