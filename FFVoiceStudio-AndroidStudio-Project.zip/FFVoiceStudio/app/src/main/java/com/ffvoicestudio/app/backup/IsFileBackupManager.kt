package com.ffvoicestudio.app.backup

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.ffvoicestudio.app.data.model.VoiceCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Custom .isfile backup archive format:
 * ZIP container storing manifest.json + audio/ + images/ so all Voice Card names,
 * categories, favorites, cover images, and audio clips remain 100% portable.
 */
object IsFileBackupManager {

    suspend fun exportCardsToIsFile(
        context: Context,
        cards: List<VoiceCard>,
        destinationUri: Uri
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val manifest = JSONObject().apply {
                put("format", "isfile")
                put("version", 1)
                put("exportedAt", System.currentTimeMillis())
                val array = JSONArray()
                cards.forEach { card ->
                    val audioFile = File(card.audioPath)
                    val audioEntryName = if (audioFile.exists()) "audio/${card.id}_${audioFile.name}" else ""
                    val imageFile = card.imagePath?.let { File(it) }?.takeIf { it.exists() }
                    val imageEntryName = imageFile?.let { "images/${card.id}_${it.name}" } ?: ""

                    array.put(JSONObject().apply {
                        put("id", card.id)
                        put("name", card.name)
                        put("category", card.category)
                        put("durationMs", card.durationMs)
                        put("isFavorite", card.isFavorite)
                        put("isPinnedToOverlay", card.isPinnedToOverlay)
                        put("sourceType", card.sourceType)
                        put("createdAt", card.createdAt)
                        put("audioEntry", audioEntryName)
                        put("imageEntry", imageEntryName)
                    })
                }
                put("cards", array)
            }

            context.contentResolver.openOutputStream(destinationUri)?.use { os ->
                ZipOutputStream(BufferedOutputStream(os)).use { zip ->
                    zip.putNextEntry(ZipEntry("manifest.json"))
                    zip.write(manifest.toString(2).toByteArray(Charsets.UTF_8))
                    zip.closeEntry()

                    cards.forEach { card ->
                        val audioFile = File(card.audioPath)
                        if (audioFile.exists()) {
                            zip.putNextEntry(ZipEntry("audio/${card.id}_${audioFile.name}"))
                            FileInputStream(audioFile).use { it.copyTo(zip) }
                            zip.closeEntry()
                        }
                        val imageFile = card.imagePath?.let { File(it) }?.takeIf { it.exists() }
                        if (imageFile != null) {
                            zip.putNextEntry(ZipEntry("images/${card.id}_${imageFile.name}"))
                            FileInputStream(imageFile).use { it.copyTo(zip) }
                            zip.closeEntry()
                        }
                    }
                }
            } ?: error("Cannot write to backup destination")

            Result.success(cards.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun importIsFile(
        context: Context,
        sourceUri: Uri,
        voicesDir: File,
        coversDir: File
    ): Result<List<VoiceCard>> = withContext(Dispatchers.IO) {
        val tempDir = File(context.cacheDir, "isfile_import_${UUID.randomUUID()}").apply { mkdirs() }
        try {
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                ZipInputStream(BufferedInputStream(input)).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            val target = File(tempDir, entry.name)
                            // Guard against Zip Path Traversal
                            if (!target.canonicalPath.startsWith(tempDir.canonicalPath + File.separator)) {
                                throw SecurityException("Invalid archive entry")
                            }
                            target.parentFile?.mkdirs()
                            FileOutputStream(target).use { out -> zip.copyTo(out) }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: error("Cannot read .isfile backup")

            val manifestFile = File(tempDir, "manifest.json")
            if (!manifestFile.exists()) error("Missing manifest.json inside .isfile backup")

            val root = JSONObject(manifestFile.readText(Charsets.UTF_8))
            val jsonCards = root.getJSONArray("cards")
            val imported = mutableListOf<VoiceCard>()

            for (i in 0 until jsonCards.length()) {
                val obj = jsonCards.getJSONObject(i)
                val newId = UUID.randomUUID().toString()
                val audioEntry = obj.optString("audioEntry")
                val srcAudio = File(tempDir, audioEntry)
                if (!srcAudio.exists()) continue

                val ext = srcAudio.extension.ifBlank { "m4a" }
                val destAudio = File(voicesDir, "$newId.$ext")
                srcAudio.copyTo(destAudio, overwrite = true)

                val imageEntry = obj.optString("imageEntry")
                val destImagePath = if (imageEntry.isNotBlank()) {
                    val srcImg = File(tempDir, imageEntry)
                    if (srcImg.exists()) {
                        val destImg = File(coversDir, "$newId.jpg")
                        srcImg.copyTo(destImg, overwrite = true)
                        destImg.absolutePath
                    } else null
                } else null

                imported.add(
                    VoiceCard(
                        id = newId,
                        name = obj.getString("name"),
                        category = obj.optString("category", "CUSTOM"),
                        audioPath = destAudio.absolutePath,
                        imagePath = destImagePath,
                        durationMs = obj.optLong("durationMs", 0L),
                        isFavorite = obj.optBoolean("isFavorite", false),
                        isPinnedToOverlay = obj.optBoolean("isPinnedToOverlay", false),
                        sourceType = obj.optString("sourceType", "AUDIO"),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
            Result.success(imported)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            tempDir.deleteRecursively()
        }
    }

    suspend fun shareSingleVoiceCard(context: Context, card: VoiceCard) = withContext(Dispatchers.IO) {
        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeName = card.name.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "voice_card" }
        val outFile = File(exportsDir, "$safeName.isfile")
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", outFile)
        exportCardsToIsFile(context, listOf(card), uri)

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "${card.name} — FF Voice Studio")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        withContext(Dispatchers.Main) {
            context.startActivity(Intent.createChooser(shareIntent, "Share Voice Card").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }
}
