package com.ffvoicestudio.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.ffvoicestudio.app.R
import com.ffvoicestudio.app.data.model.VoiceCard
import com.ffvoicestudio.app.media.PlaybackState
import com.ffvoicestudio.app.ui.theme.CyanPurpleGradient
import com.ffvoicestudio.app.ui.theme.HeaderPurpleGradient
import com.ffvoicestudio.app.ui.theme.NeonCyan
import java.io.File
import kotlin.math.roundToInt

/**
 * IS FF VOICE — Three-column Soundboard interface preserved with:
 * - Header: IS FF VOICE logo, Stop All, Minimize, Close
 * - Main controls: Microphone status, Master Volume slider, Sound Card button, Add Voice button
 * - 3-Column Soundboard grid with thumbnails, voice titles, and circular cyan Play buttons
 */
@Composable
fun HomeScreen(
    allVoices: List<VoiceCard>,
    playbackState: PlaybackState,
    masterVolume: Float,
    micPermissionGranted: Boolean,
    isFloatingEnabled: Boolean,
    onStopAll: () -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onOpenSoundCards: () -> Unit,
    onAddVoiceClick: () -> Unit,
    onTogglePlay: (VoiceCard) -> Unit,
    onStopCard: (String) -> Unit,
    onToggleFavorite: (VoiceCard) -> Unit,
    onEditCard: (VoiceCard) -> Unit
) {
    var controlsMinimized by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header: IS FF VOICE logo · Stop All · Minimize · Close
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(HeaderPurpleGradient)
                .border(1.dp, NeonCyan.copy(alpha = 0.25f), RoundedCornerShape(18.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF070B16)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_launcher_foreground),
                        contentDescription = "IS FF VOICE",
                        modifier = Modifier.size(30.dp)
                    )
                }
                Column {
                    Text(
                        text = "IS FF VOICE",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1
                    )
                    Text(
                        text = if (isFloatingEnabled) "Overlay Ready" else "TECNO KG5k · API 30",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonCyan,
                        maxLines = 1
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(
                    onClick = onStopAll,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                    modifier = Modifier.height(36.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color(0x33EF4444),
                        contentColor = Color(0xFFFCA5A5)
                    )
                ) {
                    Icon(Icons.Rounded.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Stop All", style = MaterialTheme.typography.labelMedium)
                }

                IconButton(
                    onClick = {
                        controlsMinimized = !controlsMinimized
                        onMinimize()
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (controlsMinimized) Icons.Rounded.ExpandMore else Icons.Rounded.Minimize,
                        contentDescription = "Minimize",
                        tint = NeonCyan
                    )
                }

                IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color(0xFFCBD5E1))
                }
            }
        }

        // Main Controls: Microphone status, Volume slider, Sound Card button, Add Voice button
        if (!controlsMinimized) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(
                            imageVector = if (micPermissionGranted) Icons.Rounded.Mic else Icons.Rounded.MicOff,
                            contentDescription = null,
                            tint = if (micPermissionGranted) NeonCyan else Color(0xFF94A3B8),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (micPermissionGranted) "Mic: Permission Granted" else "Mic: Not Granted",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        text = "Vol ${(masterVolume * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonCyan
                    )
                }

                Slider(
                    value = masterVolume,
                    onValueChange = onVolumeChange,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan
                    ),
                    modifier = Modifier.height(28.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onOpenSoundCards,
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.LibraryMusic, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sound Card", maxLines = 1)
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(CyanPurpleGradient)
                            .clickable { onAddVoiceClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Rounded.Add, contentDescription = null, tint = Color(0xFF04101A), modifier = Modifier.size(18.dp))
                            Text(
                                text = "Add Voice",
                                color = Color(0xFF04101A),
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Three-column Soundboard Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            items(allVoices, key = { it.id }) { card ->
                val track = playbackState.activeTracks[card.id]
                val isPlaying = track?.isPlaying == true
                SoundboardGridCard(
                    card = card,
                    isActive = track != null,
                    isPlaying = isPlaying,
                    progress = track?.progress ?: 0f,
                    onPlayPause = { onTogglePlay(card) },
                    onStop = { onStopCard(card.id) },
                    onToggleFav = { onToggleFavorite(card) },
                    onEdit = { onEditCard(card) }
                )
            }
        }
    }
}

@Composable
private fun SoundboardGridCard(
    card: VoiceCard,
    isActive: Boolean,
    isPlaying: Boolean,
    progress: Float,
    onPlayPause: () -> Unit,
    onStop: () -> Unit,
    onToggleFav: () -> Unit,
    onEdit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(
                width = 1.dp,
                color = if (isActive) NeonCyan else MaterialTheme.colorScheme.outline,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onEdit() }
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.15f)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (card.imagePath != null) {
                AsyncImage(
                    model = File(card.imagePath),
                    contentDescription = card.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(28.dp))
            }

            IconButton(
                onClick = onToggleFav,
                modifier = Modifier.align(Alignment.TopEnd).size(28.dp)
            ) {
                Icon(
                    imageVector = if (card.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    contentDescription = null,
                    tint = if (card.isFavorite) NeonCyan else Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Text(
            text = card.name,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(CyanPurpleGradient)
                    .clickable { onPlayPause() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = "Play",
                    tint = Color(0xFF04101A)
                )
            }

            if (isActive) {
                IconButton(onClick = onStop, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Rounded.Stop, contentDescription = "Stop", tint = Color(0xFFFCA5A5), modifier = Modifier.size(18.dp))
                }
            }
        }

        if (isActive) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(3.dp)),
                color = NeonCyan,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
fun VoiceCompactCard(
    card: VoiceCard,
    isPlaying: Boolean,
    onPlay: () -> Unit,
    onEdit: () -> Unit
) {
    SoundboardGridCard(
        card = card,
        isActive = isPlaying,
        isPlaying = isPlaying,
        progress = 0f,
        onPlayPause = onPlay,
        onStop = {},
        onToggleFav = {},
        onEdit = onEdit
    )
}

@Composable
fun VoiceRowCard(
    card: VoiceCard,
    isActive: Boolean,
    isPlaying: Boolean,
    progress: Float,
    onPlay: () -> Unit,
    onToggleFav: () -> Unit,
    onEdit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, if (isActive) NeonCyan else MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            .clickable { onPlay() }
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (card.imagePath != null) {
                    AsyncImage(
                        model = File(card.imagePath),
                        contentDescription = card.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = NeonCyan)
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(card.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    text = "${card.category.lowercase().replaceFirstChar { it.uppercase() }} · ${formatDuration(card.durationMs)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(onClick = onToggleFav) {
                Icon(
                    imageVector = if (card.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    contentDescription = null,
                    tint = if (card.isFavorite) NeonCyan else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Rounded.MoreVert, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(CyanPurpleGradient)
                    .clickable { onPlay() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = "Play",
                    tint = Color(0xFF04101A)
                )
            }
        }
        if (isActive && progress > 0f) {
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(4.dp)),
                color = NeonCyan,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

fun formatDuration(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    val min = totalSec / 60
    val sec = totalSec % 60
    return "$min:${sec.toString().padStart(2, '0')}"
}
