package com.ffvoicestudio.app.ui.viewmodel

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.speech.tts.Voice
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ffvoicestudio.app.FFVoiceApp
import com.ffvoicestudio.app.backup.IsFileBackupManager
import com.ffvoicestudio.app.data.model.AppLanguage
import com.ffvoicestudio.app.data.model.AppSettings
import com.ffvoicestudio.app.data.model.AudioQuality
import com.ffvoicestudio.app.data.model.VoiceCard
import com.ffvoicestudio.app.data.model.VoiceCategory
import com.ffvoicestudio.app.diagnostics.AudioDiagnosticsHelper
import com.ffvoicestudio.app.diagnostics.VoiceCompatibilityReport
import com.ffvoicestudio.app.media.PlaybackState
import com.ffvoicestudio.app.media.VideoAudioExtractor
import com.ffvoicestudio.app.overlay.FloatingSoundboardService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

enum class SortOrder { NEWEST, OLDEST }

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as FFVoiceApp
    private val repo = app.repository
    private val settingsStore = app.settingsStore
    val player = app.audioPlayer
    val tts = app.ttsManager

    val settings: StateFlow<AppSettings> = settingsStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    val playbackState: StateFlow<PlaybackState> = player.state
    val recentlyAdded = repo.recentlyAdded.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val favorites = repo.favorites.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow<String?>(null)
    val sortOrder = MutableStateFlow(SortOrder.NEWEST)
    val statusMessage = MutableStateFlow<String?>(null)
    val compatibilityReport = MutableStateFlow(VoiceCompatibilityReport())
    val micPermissionGranted = MutableStateFlow(checkMicPermission())

    init {
        viewModelScope.launch {
            val saved = settingsStore.settingsFlow.first()
            player.setMasterVolume(saved.masterVolume)
        }
    }

    val libraryCards: StateFlow<List<VoiceCard>> = combine(
        repo.voicesNewest,
        repo.voicesOldest,
        searchQuery,
        selectedCategory,
        sortOrder
    ) { newest, oldest, query, cat, order ->
        val base = if (order == SortOrder.NEWEST) newest else oldest
        base.filter { card ->
            val matchesQuery = query.isBlank() || card.name.contains(query, ignoreCase = true)
            val matchesCat = cat == null || card.category == cat
            matchesQuery && matchesCat
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun checkMicPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            app,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun refreshMicStatus() {
        micPermissionGranted.value = checkMicPermission()
    }

    fun runVoiceCompatibilityTest() = viewModelScope.launch {
        micPermissionGranted.value = checkMicPermission()
        val report = withContext(Dispatchers.IO) {
            AudioDiagnosticsHelper.runCompatibilityTest(app)
        }
        compatibilityReport.value = report
    }

    fun togglePlay(card: VoiceCard) {
        player.togglePlay(card)
    }

    fun stopIndividual(cardId: String) {
        player.stopSound(cardId)
    }

    fun stopAllSounds() {
        player.stopAll()
    }

    fun setMasterVolume(volume: Float) {
        player.setMasterVolume(volume)
        viewModelScope.launch { settingsStore.setMasterVolume(volume) }
    }

    fun setCardVolume(card: VoiceCard, volume: Float) = viewModelScope.launch {
        val clamped = volume.coerceIn(0f, 1f)
        player.setCardVolume(card.id, clamped)
        repo.upsertVoiceCard(card.copy(volume = clamped))
    }

    fun toggleFavorite(card: VoiceCard) = viewModelScope.launch {
        repo.toggleFavorite(card)
    }

    fun togglePinToOverlay(card: VoiceCard) = viewModelScope.launch {
        repo.togglePinToOverlay(card)
    }

    fun deleteCard(card: VoiceCard) = viewModelScope.launch {
        player.stopSound(card.id)
        repo.deleteVoiceCard(card)
    }

    fun saveVoiceCard(
        existing: VoiceCard?,
        name: String,
        category: VoiceCategory,
        audioUri: Uri?,
        videoUri: Uri?,
        imageUri: Uri?,
        isFavorite: Boolean,
        isPinned: Boolean,
        onComplete: () -> Unit
    ) = viewModelScope.launch {
        try {
            var audioPath = existing?.audioPath ?: ""
            var durationMs = existing?.durationMs ?: 0L
            var sourceType = existing?.sourceType ?: "AUDIO"

            if (videoUri != null) {
                val extracted = VideoAudioExtractor.extractAudioToM4a(app, videoUri, repo.voicesDir)
                val file = extracted.getOrThrow()
                audioPath = file.absolutePath
                durationMs = repo.probeDuration(file)
                sourceType = "VIDEO_EXTRACTED"
            } else if (audioUri != null) {
                val (file, dur) = repo.copyAudioFromUri(audioUri)
                audioPath = file.absolutePath
                durationMs = dur
                sourceType = "AUDIO"
            }

            if (audioPath.isBlank()) {
                statusMessage.value = "Please select an audio or video file"
                return@launch
            }

            val imagePath = if (imageUri != null) {
                repo.saveCompressedCover(imageUri).absolutePath
            } else {
                existing?.imagePath
            }

            val card = (existing ?: VoiceCard(
                id = UUID.randomUUID().toString(),
                name = name.trim(),
                audioPath = audioPath
            )).copy(
                name = name.trim(),
                category = category.name,
                audioPath = audioPath,
                imagePath = imagePath,
                durationMs = durationMs,
                isFavorite = isFavorite,
                isPinnedToOverlay = isPinned,
                sourceType = sourceType
            )
            repo.upsertVoiceCard(card)
            onComplete()
        } catch (e: Exception) {
            statusMessage.value = e.localizedMessage ?: "Failed to save voice card"
        }
    }

    fun saveTtsAsCard(
        name: String,
        text: String,
        voice: Voice?,
        pitch: Float,
        rate: Float,
        category: VoiceCategory,
        onSuccess: () -> Unit
    ) = viewModelScope.launch {
        val result = tts.synthesizeToWav(text, voice, pitch, rate, repo.voicesDir)
        result.onSuccess { file ->
            val duration = repo.probeDuration(file)
            repo.upsertVoiceCard(
                VoiceCard(
                    name = name.ifBlank { text.take(28) },
                    category = category.name,
                    audioPath = file.absolutePath,
                    durationMs = duration,
                    sourceType = "TTS"
                )
            )
            statusMessage.value = "Saved TTS Voice Card"
            onSuccess()
        }.onFailure {
            statusMessage.value = it.localizedMessage ?: "TTS synthesis failed"
        }
    }

    fun exportBackup(destinationUri: Uri) = viewModelScope.launch {
        val cards = repo.getAllSnapshot()
        IsFileBackupManager.exportCardsToIsFile(app, cards, destinationUri)
            .onSuccess { count -> statusMessage.value = "Exported $count voice cards (.isfile)" }
            .onFailure { statusMessage.value = it.localizedMessage ?: "Export failed" }
    }

    fun importBackup(sourceUri: Uri) = viewModelScope.launch {
        IsFileBackupManager.importIsFile(app, sourceUri, repo.voicesDir, repo.coversDir)
            .onSuccess { cards ->
                cards.forEach { repo.upsertVoiceCard(it) }
                statusMessage.value = "Imported ${cards.size} voice cards"
            }
            .onFailure { statusMessage.value = it.localizedMessage ?: "Import failed" }
    }

    fun shareVoiceCard(card: VoiceCard) = viewModelScope.launch {
        IsFileBackupManager.shareSingleVoiceCard(app, card)
    }

    fun setDarkTheme(dark: Boolean) = viewModelScope.launch { settingsStore.setDarkTheme(dark) }
    fun setLanguage(lang: AppLanguage) = viewModelScope.launch { settingsStore.setLanguage(lang) }
    fun setAudioQuality(q: AudioQuality) = viewModelScope.launch { settingsStore.setAudioQuality(q) }

    fun setFloatingPanelEnabled(enabled: Boolean) = viewModelScope.launch {
        if (enabled && !Settings.canDrawOverlays(app)) {
            statusMessage.value = "Overlay permission required — app remains usable without overlay"
            return@launch
        }
        settingsStore.setFloatingPanelEnabled(enabled)
        val intent = Intent(app, FloatingSoundboardService::class.java)
        if (enabled) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                app.startForegroundService(intent)
            } else {
                app.startService(intent)
            }
        } else {
            app.stopService(intent)
        }
    }

    fun clearStatus() {
        statusMessage.value = null
    }
}
