package com.ffvoicestudio.app

import android.app.Application
import android.content.ComponentCallbacks2
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.ffvoicestudio.app.data.local.FFVoiceDatabase
import com.ffvoicestudio.app.data.local.SettingsDataStore
import com.ffvoicestudio.app.data.repository.VoiceRepository
import com.ffvoicestudio.app.media.VoiceAudioPlayer
import com.ffvoicestudio.app.tts.VoiceTtsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class FFVoiceApp : Application(), ImageLoaderFactory {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val database: FFVoiceDatabase by lazy { FFVoiceDatabase.getInstance(this) }
    val repository: VoiceRepository by lazy { VoiceRepository(this, database.voiceCardDao()) }
    val settingsStore: SettingsDataStore by lazy { SettingsDataStore(this) }
    val audioPlayer: VoiceAudioPlayer by lazy { VoiceAudioPlayer(this, appScope) }
    val ttsManager: VoiceTtsManager by lazy { VoiceTtsManager(this) }

    /**
     * Memory-capped Coil loader optimized for low-RAM devices (TECNO KG5k).
     */
    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.15)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(16L * 1024 * 1024)
                    .build()
            }
            .crossfade(false)
            .build()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            audioPlayer.releaseOnLowMemory()
        }
    }
}
