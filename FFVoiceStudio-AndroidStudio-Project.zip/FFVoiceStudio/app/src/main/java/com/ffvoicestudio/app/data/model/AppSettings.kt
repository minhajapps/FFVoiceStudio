package com.ffvoicestudio.app.data.model

enum class AudioQuality(val label: String, val sampleRateHz: Int, val bitRate: Int) {
    STANDARD("Standard (22 kHz · Low RAM)", 22050, 64_000),
    HIGH("High (44.1 kHz)", 44100, 128_000),
    STUDIO("Studio (48 kHz)", 48000, 192_000)
}

enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    BANGLA("bn", "বাংলা")
}

data class AppSettings(
    val isDarkTheme: Boolean = true,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val audioQuality: AudioQuality = AudioQuality.HIGH,
    val masterVolume: Float = 1.0f,
    val isFloatingPanelEnabled: Boolean = false
)
