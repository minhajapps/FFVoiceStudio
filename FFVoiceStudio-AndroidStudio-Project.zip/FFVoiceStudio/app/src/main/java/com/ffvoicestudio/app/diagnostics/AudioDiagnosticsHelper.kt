package com.ffvoicestudio.app.diagnostics

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import androidx.core.content.ContextCompat

data class VoiceCompatibilityReport(
    val deviceModel: String = "${Build.MANUFACTURER} ${Build.MODEL}",
    val androidVersion: String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
    val micPermissionGranted: Boolean = false,
    val inputDeviceName: String = "Not tested",
    val outputDeviceName: String = "Not tested",
    val bluetoothStatus: String = "Not tested",
    val recordingConfigSummary: String = "Not tested",
    val micCaptureStatus: String = "Not tested",
    val directVoiceRoutingSupported: Boolean = false,
    val directRoutingMessage: String = "",
    val technicalExplanation: String = "",
    val testedAtTimestamp: Long = 0L
)

/**
 * Reports genuine Android 11 (API 30) audio hardware & permission capabilities.
 * Never attempts to bypass Android microphone privacy protections, never injects audio into
 * Free Fire, and never claims unsupported VoIP uplink routing works.
 */
object AudioDiagnosticsHelper {

    @SuppressLint("MissingPermission")
    fun runCompatibilityTest(context: Context): VoiceCompatibilityReport {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val micGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)

        val inputSummary = if (inputs.isEmpty()) {
            "No audio input device detected"
        } else {
            inputs.joinToString(", ") { "${it.productName} (${deviceTypeLabel(it.type)})" }
        }

        val outputSummary = if (outputs.isEmpty()) {
            "No audio output device detected"
        } else {
            outputs.joinToString(", ") { "${it.productName} (${deviceTypeLabel(it.type)})" }
        }

        val hasBtDevice = (inputs + outputs).any {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
        }
        val btStatus = when {
            audioManager.isBluetoothScoOn -> "Connected (Bluetooth SCO Headset Mic)"
            audioManager.isBluetoothA2dpOn -> "Connected (Bluetooth A2DP Media)"
            hasBtDevice -> "Paired Bluetooth audio device available"
            else -> "Disconnected"
        }

        val activeRecSummary = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val configs = audioManager.activeRecordingConfigurations
            if (configs.isEmpty()) {
                "No active concurrent recording session (Audio mode: ${audioModeLabel(audioManager.mode)})"
            } else {
                configs.joinToString("; ") { cfg ->
                    "Source ${cfg.clientAudioSource} · ${cfg.format.sampleRate} Hz"
                }
            }
        } else {
            "Recording config query requires Android 7.0+"
        }

        val captureStatus = if (!micGranted) {
            "Permission denied — grant RECORD_AUDIO to probe microphone hardware"
        } else {
            probeMicrophoneCapture()
        }

        // Standard Android 11 (API 30) isolates microphone capture per app and blocks third-party
        // apps from injecting PCM playback into another app's VOICE_COMMUNICATION stream.
        val directRoutingMessage =
            "Direct Free Fire microphone routing is not supported by this device or Android configuration."

        val explanation =
            "Android 11 (API 30) enforces strict microphone privacy and per-app audio isolation. " +
                "Standard user apps cannot inject soundboard audio directly into Garena Free Fire's " +
                "in-game voice chat uplink without system/root privileges. Your normal IS FF VOICE " +
                "soundboard remains 100% functional through device speakers, wired headsets, or Bluetooth."

        return VoiceCompatibilityReport(
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            micPermissionGranted = micGranted,
            inputDeviceName = inputSummary,
            outputDeviceName = outputSummary,
            bluetoothStatus = btStatus,
            recordingConfigSummary = activeRecSummary,
            micCaptureStatus = captureStatus,
            directVoiceRoutingSupported = false,
            directRoutingMessage = directRoutingMessage,
            technicalExplanation = explanation,
            testedAtTimestamp = System.currentTimeMillis()
        )
    }

    @SuppressLint("MissingPermission")
    private fun probeMicrophoneCapture(): String {
        val sampleRate = 16000
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return "Hardware rejected 16 kHz PCM capture"

        var recorder: AudioRecord? = null
        return try {
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                "AudioRecord initialization failed (mic may be held exclusively by another app)"
            } else {
                recorder.startRecording()
                val probe = ShortArray(256)
                val read = recorder.read(probe, 0, probe.size)
                recorder.stop()
                if (read > 0) "Active & readable ($sampleRate Hz Mono PCM)"
                else "Mic initialized but returned empty samples (in use by call/game)"
            }
        } catch (e: Exception) {
            "Mic capture unavailable: ${e.localizedMessage ?: "busy"}"
        } finally {
            runCatching { recorder?.release() }
        }
    }

    private fun deviceTypeLabel(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Built-in Mic"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Speaker"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Earpiece"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired Headset"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired Headphones"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth SCO"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth A2DP"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB Headset"
        else -> "Audio Device"
    }

    private fun audioModeLabel(mode: Int): String = when (mode) {
        AudioManager.MODE_NORMAL -> "Normal"
        AudioManager.MODE_IN_COMMUNICATION -> "In Communication (VoIP)"
        AudioManager.MODE_IN_CALL -> "In Call"
        AudioManager.MODE_RINGTONE -> "Ringtone"
        else -> "Mode $mode"
    }
}
