package com.ffvoicestudio.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ffvoicestudio.app.data.model.AppLanguage
import com.ffvoicestudio.app.data.model.AppSettings
import com.ffvoicestudio.app.data.model.AudioQuality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ff_voice_settings")

class SettingsDataStore(private val context: Context) {
    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val LANGUAGE = stringPreferencesKey("language")
        val AUDIO_QUALITY = stringPreferencesKey("audio_quality")
        val MASTER_VOLUME = floatPreferencesKey("master_volume")
        val FLOATING_ENABLED = booleanPreferencesKey("floating_enabled")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            isDarkTheme = prefs[Keys.DARK_THEME] ?: true,
            language = AppLanguage.entries.firstOrNull { it.code == prefs[Keys.LANGUAGE] }
                ?: AppLanguage.ENGLISH,
            audioQuality = AudioQuality.entries.firstOrNull { it.name == prefs[Keys.AUDIO_QUALITY] }
                ?: AudioQuality.HIGH,
            masterVolume = (prefs[Keys.MASTER_VOLUME] ?: 1.0f).coerceIn(0f, 1f),
            isFloatingPanelEnabled = prefs[Keys.FLOATING_ENABLED] ?: false
        )
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setAudioQuality(quality: AudioQuality) {
        context.dataStore.edit { it[Keys.AUDIO_QUALITY] = quality.name }
    }

    suspend fun setMasterVolume(volume: Float) {
        context.dataStore.edit { it[Keys.MASTER_VOLUME] = volume.coerceIn(0f, 1f) }
    }

    suspend fun setFloatingPanelEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.FLOATING_ENABLED] = enabled }
    }
}
