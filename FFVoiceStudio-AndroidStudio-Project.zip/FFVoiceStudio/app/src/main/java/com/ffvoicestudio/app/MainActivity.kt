package com.ffvoicestudio.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ffvoicestudio.app.data.model.VoiceCard
import com.ffvoicestudio.app.ui.screens.*
import com.ffvoicestudio.app.ui.theme.FFVoiceStudioTheme
import com.ffvoicestudio.app.ui.viewmodel.MainViewModel
import com.ffvoicestudio.app.ui.viewmodel.SortOrder

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIsFileIntent(intent)

        setContent {
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val libraryCards by viewModel.libraryCards.collectAsStateWithLifecycle()
            val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
            val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
            val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
            val sortOrder by viewModel.sortOrder.collectAsStateWithLifecycle()
            val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
            val compatibilityReport by viewModel.compatibilityReport.collectAsStateWithLifecycle()
            val micGranted by viewModel.micPermissionGranted.collectAsStateWithLifecycle()

            val ttsVoices by viewModel.tts.voices.collectAsStateWithLifecycle()
            val ttsReady by viewModel.tts.isReady.collectAsStateWithLifecycle()
            val ttsSpeaking by viewModel.tts.isSpeaking.collectAsStateWithLifecycle()

            LaunchedEffect(settings.language) {
                val locales = LocaleListCompat.forLanguageTags(settings.language.code)
                if (AppCompatDelegate.getApplicationLocales() != locales) {
                    AppCompatDelegate.setApplicationLocales(locales)
                }
            }

            var currentTab by remember { mutableIntStateOf(0) }
            var showEditorSheet by remember { mutableStateOf(false) }
            var editingCard by remember { mutableStateOf<VoiceCard?>(null) }
            val snackbarHostState = remember { SnackbarHostState() }

            LaunchedEffect(statusMessage) {
                statusMessage?.let { msg ->
                    snackbarHostState.showSnackbar(msg)
                    viewModel.clearStatus()
                }
            }

            FFVoiceStudioTheme(darkTheme = settings.isDarkTheme) {
                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = currentTab == 0,
                                onClick = { currentTab = 0 },
                                icon = { Icon(Icons.Rounded.GraphicEq, contentDescription = null) },
                                label = { Text("Board") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 1,
                                onClick = { currentTab = 1 },
                                icon = { Icon(Icons.Rounded.LibraryMusic, contentDescription = null) },
                                label = { Text(stringResource(R.string.nav_library)) }
                            )
                            NavigationBarItem(
                                selected = currentTab == 2,
                                onClick = { currentTab = 2 },
                                icon = { Icon(Icons.Rounded.RecordVoiceOver, contentDescription = null) },
                                label = { Text(stringResource(R.string.nav_tts)) }
                            )
                            NavigationBarItem(
                                selected = currentTab == 3,
                                onClick = {
                                    currentTab = 3
                                    viewModel.runVoiceCompatibilityTest()
                                },
                                icon = { Icon(Icons.Rounded.VerifiedUser, contentDescription = null) },
                                label = { Text("Test") }
                            )
                            NavigationBarItem(
                                selected = currentTab == 4,
                                onClick = { currentTab = 4 },
                                icon = { Icon(Icons.Rounded.Settings, contentDescription = null) },
                                label = { Text(stringResource(R.string.nav_settings)) }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentTab) {
                            0 -> HomeScreen(
                                allVoices = libraryCards,
                                playbackState = playbackState,
                                masterVolume = settings.masterVolume,
                                micPermissionGranted = micGranted,
                                isFloatingEnabled = settings.isFloatingPanelEnabled,
                                onStopAll = viewModel::stopAllSounds,
                                onMinimize = {},
                                onClose = {
                                    viewModel.stopAllSounds()
                                    moveTaskToBack(true)
                                },
                                onVolumeChange = viewModel::setMasterVolume,
                                onOpenSoundCards = { currentTab = 1 },
                                onAddVoiceClick = {
                                    editingCard = null
                                    showEditorSheet = true
                                },
                                onTogglePlay = viewModel::togglePlay,
                                onStopCard = viewModel::stopIndividual,
                                onToggleFavorite = viewModel::toggleFavorite,
                                onEditCard = { card ->
                                    editingCard = card
                                    showEditorSheet = true
                                }
                            )
                            1 -> LibraryScreen(
                                cards = libraryCards,
                                playbackState = playbackState,
                                searchQuery = searchQuery,
                                selectedCategory = selectedCategory,
                                sortOrder = sortOrder,
                                onSearchChange = { viewModel.searchQuery.value = it },
                                onSelectCategory = { viewModel.selectedCategory.value = it },
                                onToggleSort = {
                                    viewModel.sortOrder.value =
                                        if (sortOrder == SortOrder.NEWEST) SortOrder.OLDEST else SortOrder.NEWEST
                                },
                                onTogglePlay = viewModel::togglePlay,
                                onToggleFavorite = viewModel::toggleFavorite,
                                onTogglePinOverlay = viewModel::togglePinToOverlay,
                                onShareCard = viewModel::shareVoiceCard,
                                onEditCard = { card ->
                                    editingCard = card
                                    showEditorSheet = true
                                },
                                onDeleteCard = viewModel::deleteCard
                            )
                            2 -> TtsStudioScreen(
                                voices = ttsVoices,
                                isReady = ttsReady,
                                isSpeaking = ttsSpeaking,
                                onPreview = viewModel.tts::preview,
                                onStopPreview = viewModel.tts::stop,
                                onSaveCard = { name, text, voice, pitch, rate, cat ->
                                    viewModel.saveTtsAsCard(name, text, voice, pitch, rate, cat) {
                                        currentTab = 1
                                    }
                                }
                            )
                            3 -> VoiceCompatibilityScreen(
                                report = compatibilityReport,
                                onRunTest = viewModel::runVoiceCompatibilityTest,
                                onPermissionResult = viewModel::refreshMicStatus
                            )
                            4 -> SettingsScreen(
                                settings = settings,
                                onToggleTheme = viewModel::setDarkTheme,
                                onSelectLanguage = viewModel::setLanguage,
                                onSelectQuality = viewModel::setAudioQuality,
                                onToggleFloating = viewModel::setFloatingPanelEnabled,
                                onExportIsFile = viewModel::exportBackup,
                                onImportIsFile = viewModel::importBackup
                            )
                        }
                    }
                }

                if (showEditorSheet) {
                    VoiceEditorSheet(
                        editingCard = editingCard,
                        onDismiss = { showEditorSheet = false },
                        onSave = { name, cat, audioUri, videoUri, imgUri, fav, pinned ->
                            viewModel.saveVoiceCard(
                                existing = editingCard,
                                name = name,
                                category = cat,
                                audioUri = audioUri,
                                videoUri = videoUri,
                                imageUri = imgUri,
                                isFavorite = fav,
                                isPinned = pinned,
                                onComplete = { showEditorSheet = false }
                            )
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshMicStatus()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIsFileIntent(intent)
    }

    private fun handleIncomingIsFileIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { uri -> viewModel.importBackup(uri) }
        }
    }
}
