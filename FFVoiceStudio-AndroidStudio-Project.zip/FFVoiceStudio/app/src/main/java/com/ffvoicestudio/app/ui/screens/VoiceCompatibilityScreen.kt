package com.ffvoicestudio.app.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffvoicestudio.app.diagnostics.VoiceCompatibilityReport
import com.ffvoicestudio.app.ui.theme.CyanPurpleGradient
import com.ffvoicestudio.app.ui.theme.NeonCyan

@Composable
fun VoiceCompatibilityScreen(
    report: VoiceCompatibilityReport,
    onRunTest: () -> Unit,
    onPermissionResult: () -> Unit
) {
    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        onPermissionResult()
        onRunTest()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Voice Compatibility Diagnostics",
            style = MaterialTheme.typography.headlineMedium
        )
        Text(
            text = "Inspects actual Android 11 audio devices, microphone capture capability, and Garena Free Fire voice-routing boundaries.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(CyanPurpleGradient)
                .clickable {
                    if (!report.micPermissionGranted) {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    } else {
                        onRunTest()
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = Color(0xFF04101A))
                Text(
                    text = "TEST VOICE COMPATIBILITY",
                    color = Color(0xFF04101A),
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (!report.micPermissionGranted) {
            OutlinedButton(
                onClick = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Rounded.Mic, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Grant Microphone Permission (Optional for Diagnostics)")
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            DiagnosticRow("Device", report.deviceModel)
            DiagnosticRow("Android Version", report.androidVersion)
            DiagnosticRow("Microphone Permission", if (report.micPermissionGranted) "Granted" else "Not Granted")
            DiagnosticRow("Audio Input Device", report.inputDeviceName)
            DiagnosticRow("Audio Output Device", report.outputDeviceName)
            DiagnosticRow("Bluetooth Status", report.bluetoothStatus)
            DiagnosticRow("Recording Configuration", report.recordingConfigSummary)
            DiagnosticRow("Microphone Capture Status", report.micCaptureStatus)
            DiagnosticRow(
                "Direct Voice-Routing Support",
                if (report.directVoiceRoutingSupported) "Supported" else "Unsupported (Android 11 Isolation)"
            )
        }

        if (report.testedAtTimestamp > 0L) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0x1AEF4444))
                    .border(1.dp, Color(0x55EF4444), RoundedCornerShape(18.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Info, contentDescription = null, tint = Color(0xFFFCA5A5))
                    Text(
                        text = report.directRoutingMessage,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFFFECACA)
                    )
                }
                Text(
                    text = report.technicalExplanation,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = NeonCyan
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    }
}
