package com.ffvoicestudio.app.media

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.util.UUID

/**
 * Extracts the native audio track from supported video files (MP4, MKV, WEBM, 3GP)
 * using Android's hardware-friendly MediaExtractor & MediaMuxer with zero third-party binary bloat.
 */
object VideoAudioExtractor {

    suspend fun extractAudioToM4a(
        context: Context,
        videoUri: Uri,
        outputDir: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        val outFile = File(outputDir, "${UUID.randomUUID()}.m4a")

        try {
            val pfd = context.contentResolver.openFileDescriptor(videoUri, "r")
                ?: return@withContext Result.failure(IllegalStateException("Cannot open video file"))

            pfd.use { fd ->
                extractor.setDataSource(fd.fileDescriptor)
            }

            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }

            if (audioTrackIndex == -1 || audioFormat == null) {
                return@withContext Result.failure(IllegalArgumentException("No audio track found in video"))
            }

            extractor.selectTrack(audioTrackIndex)

            val maxInputSize = if (audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(64 * 1024)
            } else {
                256 * 1024
            }

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerTrackIndex = muxer.addTrack(audioFormat)
            muxer.start()

            val buffer = ByteBuffer.allocate(maxInputSize)
            val bufferInfo = android.media.MediaCodec.BufferInfo()

            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = extractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) {
                    bufferInfo.size = 0
                    break
                }
                bufferInfo.presentationTimeUs = extractor.sampleTime
                bufferInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(muxerTrackIndex, buffer, bufferInfo)
                extractor.advance()
            }

            muxer.stop()
            Result.success(outFile)
        } catch (e: Exception) {
            outFile.delete()
            Result.failure(e)
        } finally {
            runCatching { muxer?.release() }
            runCatching { extractor.release() }
        }
    }
}
