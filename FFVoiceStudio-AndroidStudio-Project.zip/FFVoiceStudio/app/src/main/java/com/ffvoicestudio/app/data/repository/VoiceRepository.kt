package com.ffvoicestudio.app.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.ffvoicestudio.app.data.local.VoiceCardDao
import com.ffvoicestudio.app.data.model.VoiceCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class VoiceRepository(
    private val context: Context,
    private val dao: VoiceCardDao
) {
    val voicesNewest: Flow<List<VoiceCard>> = dao.observeAllNewest()
    val voicesOldest: Flow<List<VoiceCard>> = dao.observeAllOldest()
    val favorites: Flow<List<VoiceCard>> = dao.observeFavorites()
    val recentlyAdded: Flow<List<VoiceCard>> = dao.observeRecentlyAdded()
    val pinnedOverlayVoices: Flow<List<VoiceCard>> = dao.observePinnedForOverlay()

    val voicesDir: File
        get() = File(context.filesDir, "voices").apply { mkdirs() }

    val coversDir: File
        get() = File(context.filesDir, "covers").apply { mkdirs() }

    suspend fun copyAudioFromUri(uri: Uri, extension: String = "m4a"): Pair<File, Long> =
        withContext(Dispatchers.IO) {
            val outFile = File(voicesDir, "${UUID.randomUUID()}.$extension")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(outFile).use { output ->
                    input.copyTo(output)
                }
            } ?: error("Unable to open audio stream")
            val durationMs = probeDuration(outFile)
            outFile to durationMs
        }

    /**
     * Downscales and compresses cover artwork to keep memory low on budget Android phones.
     */
    suspend fun saveCompressedCover(uri: Uri): File = withContext(Dispatchers.IO) {
        val outFile = File(coversDir, "${UUID.randomUUID()}.jpg")
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, bounds)
        }
        val sampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, 512, 512)
        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        val bitmap = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOpts)
        } ?: error("Invalid image file")

        FileOutputStream(outFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
        }
        bitmap.recycle()
        outFile
    }

    suspend fun upsertVoiceCard(card: VoiceCard) = withContext(Dispatchers.IO) {
        dao.upsert(card.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun toggleFavorite(card: VoiceCard) = withContext(Dispatchers.IO) {
        dao.update(card.copy(isFavorite = !card.isFavorite, updatedAt = System.currentTimeMillis()))
    }

    suspend fun togglePinToOverlay(card: VoiceCard) = withContext(Dispatchers.IO) {
        dao.update(card.copy(isPinnedToOverlay = !card.isPinnedToOverlay, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteVoiceCard(card: VoiceCard) = withContext(Dispatchers.IO) {
        dao.delete(card)
        runCatching { File(card.audioPath).takeIf { it.exists() }?.delete() }
        card.imagePath?.let { path ->
            runCatching { File(path).takeIf { it.exists() }?.delete() }
        }
    }

    suspend fun getAllSnapshot(): List<VoiceCard> = withContext(Dispatchers.IO) {
        dao.getAllSnapshot()
    }

    fun probeDuration(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun calculateInSampleSize(width: Int, height: Int, reqWidth: Int, reqHeight: Int): Int {
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }
}
