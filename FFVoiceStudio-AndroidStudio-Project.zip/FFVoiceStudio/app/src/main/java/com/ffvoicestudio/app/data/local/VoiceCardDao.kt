package com.ffvoicestudio.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.ffvoicestudio.app.data.model.VoiceCard
import kotlinx.coroutines.flow.Flow

@Dao
interface VoiceCardDao {
    @Query("SELECT * FROM voice_cards ORDER BY createdAt DESC")
    fun observeAllNewest(): Flow<List<VoiceCard>>

    @Query("SELECT * FROM voice_cards ORDER BY createdAt ASC")
    fun observeAllOldest(): Flow<List<VoiceCard>>

    @Query("SELECT * FROM voice_cards WHERE isFavorite = 1 ORDER BY updatedAt DESC")
    fun observeFavorites(): Flow<List<VoiceCard>>

    @Query("SELECT * FROM voice_cards ORDER BY createdAt DESC LIMIT 6")
    fun observeRecentlyAdded(): Flow<List<VoiceCard>>

    @Query("SELECT * FROM voice_cards WHERE isPinnedToOverlay = 1 ORDER BY updatedAt DESC")
    fun observePinnedForOverlay(): Flow<List<VoiceCard>>

    @Query("SELECT * FROM voice_cards")
    suspend fun getAllSnapshot(): List<VoiceCard>

    @Query("SELECT * FROM voice_cards WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): VoiceCard?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(card: VoiceCard)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(cards: List<VoiceCard>)

    @Update
    suspend fun update(card: VoiceCard)

    @Delete
    suspend fun delete(card: VoiceCard)

    @Query("DELETE FROM voice_cards")
    suspend fun deleteAll()
}
