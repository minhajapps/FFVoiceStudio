package com.ffvoicestudio.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.ffvoicestudio.app.data.model.VoiceCard

@Database(
    entities = [VoiceCard::class],
    version = 2,
    exportSchema = false
)
abstract class FFVoiceDatabase : RoomDatabase() {
    abstract fun voiceCardDao(): VoiceCardDao

    companion object {
        @Volatile
        private var INSTANCE: FFVoiceDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE voice_cards ADD COLUMN volume REAL NOT NULL DEFAULT 1.0")
            }
        }

        fun getInstance(context: Context): FFVoiceDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FFVoiceDatabase::class.java,
                    "ff_voice_studio.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
