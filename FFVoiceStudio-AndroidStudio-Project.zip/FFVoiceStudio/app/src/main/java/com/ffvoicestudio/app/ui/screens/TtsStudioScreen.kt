package com.ffvoicestudio.app.ui.screens

import android.speech.tts.Voice
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.ffvoicestudio.app.R
import com.ffvoicestudio.app.data.model.VoiceCategory
import com.ffvoicestudio.app.ui.theme.NeonCyan
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TtsStudioScreen(
    voices: List<Voice>,
    isReady: Boolean,
    isSpeaking: Boolean,
    onPreview: (text: String, voice: Voice?, pitch: Float, rate: Float) -> Unit,
    onStopPreview: () -> Unit,
    onSaveCard: (name: String, text: String, voice: Voice?, pitch: Float, rate: Float, category: VoiceCategory) -> Unit
) {
    var text by remember { mutableStateOf("") }
    var cardName by remember { mutableStateOf("") }
    var selectedVoice by remember(voices) { mutableStateOf(voices.firstOrNull()) }
    var expandedVoiceMenu by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf(VoiceCategory.TACTICAL) }
    var pitch by remember { mutableFloatStateOf(1.0f) }
    var rate by remember { mutableFloatStateOf(1.0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = stringResource(R.string.tts_title), style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = cardName,
            onValueChange = { cardName = it },
            label = { Text("Voice Card Name") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text(stringResource(R.string.tts_input_hint)) },
            minLines = 4,
            maxLines = 6,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )

        // Voice Engine Selector
        ExposedDropdownMenuBox(
            expanded = expandedVoiceMenu,
            onExpandedChange = { expandedVoiceMenu = !expandedVoiceMenu }
        ) {
            OutlinedTextField(
                value = selectedVoice?.let { "${it.locale.displayLanguage} · ${it.name}" }
                    ?: if (isReady) "Default System Voice" else "Initializing TTS…",
                onValueChange = {},
                readOnly = true,
                label = { Text(stringResource(R.string.tts_select_voice)) },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedVoiceMenu) },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = expandedVoiceMenu,
                onDismissRequest = { expandedVoiceMenu = false }
            ) {
                voices.forEach { voice ->
                    DropdownMenuItem(
                        text = { Text("${voice.locale.displayName} (${voice.name})") },
                        onClick = {
                            selectedVoice = voice
                            expandedVoiceMenu = false
                        }
                    )
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Pitch (${String.format(Locale.US, "%.2f", pitch)}x)", style = MaterialTheme.typography.labelMedium)
            Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.6f..1.5f)
            Text("Speed (${String.format(Locale.US, "%.2f", rate)}x)", style = MaterialTheme.typography.labelMedium)
            Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.6f..1.5f)
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = {
                    if (isSpeaking) onStopPreview()
                    else onPreview(text, selectedVoice, pitch, rate)
                },
                enabled = isReady && text.isNotBlank(),
                modifier = Modifier.weight(1f).height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(if (isSpeaking) Icons.Rounded.Stop else Icons.Rounded.VolumeUp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isSpeaking) "Stop" else stringResource(R.string.tts_preview))
            }

            Button(
                onClick = { onSaveCard(cardName, text, selectedVoice, pitch, rate, selectedCategory) },
                enabled = isReady && text.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color(0xFF04101A)),
                modifier = Modifier.weight(1f).height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Rounded.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.tts_save_card))
            }
        }
    }
}
