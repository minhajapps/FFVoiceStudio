package com.ffvoicestudio.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.ffvoicestudio.app.R
import com.ffvoicestudio.app.data.model.VoiceCard
import com.ffvoicestudio.app.data.model.VoiceCategory
import com.ffvoicestudio.app.media.PlaybackState
import com.ffvoicestudio.app.ui.viewmodel.SortOrder

@Composable
fun LibraryScreen(
    cards: List<VoiceCard>,
    playbackState: PlaybackState,
    searchQuery: String,
    selectedCategory: String?,
    sortOrder: SortOrder,
    onSearchChange: (String) -> Unit,
    onSelectCategory: (String?) -> Unit,
    onToggleSort: () -> Unit,
    onTogglePlay: (VoiceCard) -> Unit,
    onToggleFavorite: (VoiceCard) -> Unit,
    onTogglePinOverlay: (VoiceCard) -> Unit,
    onShareCard: (VoiceCard) -> Unit,
    onEditCard: (VoiceCard) -> Unit,
    onDeleteCard: (VoiceCard) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.nav_library),
                style = MaterialTheme.typography.headlineMedium
            )
            TextButton(onClick = onToggleSort) {
                Icon(Icons.Rounded.SwapVert, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    if (sortOrder == SortOrder.NEWEST) stringResource(R.string.sort_newest)
                    else stringResource(R.string.sort_oldest)
                )
            }
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text(stringResource(R.string.search_voices)) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )

        // Category Filter Segmented Strip
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedCategory == null,
                onClick = { onSelectCategory(null) },
                label = { Text(stringResource(R.string.cat_all)) }
            )
            VoiceCategory.entries.forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat.name,
                    onClick = { onSelectCategory(cat.name) },
                    label = { Text(cat.labelEn) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(cards, key = { it.id }) { card ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    VoiceRowCard(
                        card = card,
                        isActive = playbackState.activeCardId == card.id,
                        isPlaying = playbackState.activeCardId == card.id && playbackState.isPlaying,
                        progress = if (playbackState.activeCardId == card.id) playbackState.progress else 0f,
                        onPlay = { onTogglePlay(card) },
                        onToggleFav = { onToggleFavorite(card) },
                        onEdit = { onEditCard(card) }
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { onTogglePinOverlay(card) }) {
                            Icon(
                                if (card.isPinnedToOverlay) Icons.Rounded.PushPin else Icons.Rounded.OutlinedFlag,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (card.isPinnedToOverlay) "Pinned" else "Pin Overlay")
                        }
                        TextButton(onClick = { onShareCard(card) }) {
                            Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share")
                        }
                        TextButton(onClick = { onDeleteCard(card) }) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Delete")
                        }
                    }
                }
            }
        }
    }
}
