package com.ffvoicestudio.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val NavyBg = Color(0xFF070B16)
val NavySurface = Color(0xFF0E1528)
val NavySurfaceHigh = Color(0xFF151E38)
val NeonCyan = Color(0xFF00E5FF)
val CyberPurple = Color(0xFF7C3AED)

val CyanPurpleGradient = Brush.linearGradient(listOf(NeonCyan, CyberPurple))
val HeaderPurpleGradient = Brush.horizontalGradient(listOf(Color(0xFF121A34), Color(0xFF23164A)))

private val DarkColors = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF04101A),
    secondary = CyberPurple,
    onSecondary = Color.White,
    background = NavyBg,
    onBackground = Color(0xFFF1F5F9),
    surface = NavySurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = NavySurfaceHigh,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF232F52)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0284C7),
    onPrimary = Color.White,
    secondary = CyberPurple,
    background = Color(0xFFF4F7FB),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE8EEF7),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFD5DFEE)
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 18.sp, lineHeight = 24.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 19.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 19.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 15.sp)
)

@Composable
fun FFVoiceStudioTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
