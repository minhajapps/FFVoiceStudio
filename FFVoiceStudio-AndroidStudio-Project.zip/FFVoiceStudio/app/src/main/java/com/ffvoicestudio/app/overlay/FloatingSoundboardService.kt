package com.ffvoicestudio.app.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.ffvoicestudio.app.FFVoiceApp
import com.ffvoicestudio.app.MainActivity
import com.ffvoicestudio.app.R
import com.ffvoicestudio.app.data.model.VoiceCard
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Optional compact three-column Floating Gaming Panel for Android 11 (TECNO KG5k).
 * - Shows ALL soundboard voices by default (with All / Pinned toggle)
 * - Clamps within screen boundaries
 * - Draggable header
 * - Minimize & Close controls
 * - Large touch-friendly (>= 44dp) circular cyan Play controls in a 3-column grid
 */
class FloatingSoundboardService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var isMinimized = false
    private var showAllSounds = true
    private var latestCards: List<VoiceCard> = emptyList()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(NOTIFICATION_ID, buildNotification())
        attachOverlay()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachOverlay() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(metrics)
        val dp = metrics.density
        val panelWidth = (304 * dp).toInt().coerceAtMost(metrics.widthPixels - (16 * dp).toInt())

        val params = WindowManager.LayoutParams(
            panelWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * dp).toInt()
            y = (96 * dp).toInt()
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (12 * dp).toInt()
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#F2080C18"), Color.parseColor("#F2111830"))
            ).apply {
                cornerRadius = 20f * dp
                setStroke((1.5f * dp).toInt(), Color.parseColor("#6600E5FF"))
            }
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleView = TextView(this).apply {
            text = "IS FF VOICE"
            setTextColor(Color.parseColor("#FF00E5FF"))
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val gridContainer = GridLayout(this).apply {
            columnCount = 3
            setPadding(0, (10 * dp).toInt(), 0, 0)
        }

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (240 * dp).toInt()
            )
            addView(gridContainer)
        }

        val app = application as FFVoiceApp

        val filterBtn = TextView(this).apply {
            text = "ALL"
            setTextColor(Color.parseColor("#FF00E5FF"))
            textSize = 10f
            setPadding((8 * dp).toInt(), (6 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2600E5FF"))
                cornerRadius = 10f * dp
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = (6 * dp).toInt() }
            layoutParams = lp
            setOnClickListener {
                showAllSounds = !showAllSounds
                text = if (showAllSounds) "ALL" else "PIN"
                renderThreeColumnGrid(gridContainer, latestCards, app, dp)
            }
        }

        val stopAllBtn = TextView(this).apply {
            text = "STOP"
            setTextColor(Color.WHITE)
            textSize = 10f
            setPadding((10 * dp).toInt(), (6 * dp).toInt(), (10 * dp).toInt(), (6 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33EF4444"))
                cornerRadius = 10f * dp
            }
            setOnClickListener {
                app.audioPlayer.stopAll()
            }
        }

        val minimizeBtn = TextView(this).apply {
            text = "—"
            setTextColor(Color.parseColor("#FF00E5FF"))
            textSize = 14f
            setPadding((10 * dp).toInt(), (4 * dp).toInt(), (10 * dp).toInt(), (4 * dp).toInt())
            setOnClickListener {
                isMinimized = !isMinimized
                scroll.visibility = if (isMinimized) View.GONE else View.VISIBLE
                text = if (isMinimized) "+" else "—"
            }
        }

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FFCBD5E1"))
            textSize = 13f
            setPadding((8 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt())
            setOnClickListener {
                serviceScope.launch {
                    app.settingsStore.setFloatingPanelEnabled(false)
                }
                stopSelf()
            }
        }

        headerRow.addView(titleView)
        headerRow.addView(filterBtn)
        headerRow.addView(stopAllBtn)
        headerRow.addView(minimizeBtn)
        headerRow.addView(closeBtn)
        root.addView(headerRow)
        root.addView(scroll)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        headerRow.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 4 || abs(dy) > 4) {
                        val maxX = (metrics.widthPixels - root.width.coerceAtLeast(panelWidth)).coerceAtLeast(0)
                        val maxY = (metrics.heightPixels - root.height.coerceAtLeast((80 * dp).toInt())).coerceAtLeast(0)
                        params.x = (initialX + dx).coerceIn(0, maxX)
                        params.y = (initialY + dy).coerceIn(0, maxY)
                        windowManager.updateViewLayout(root, params)
                    }
                    true
                }
                else -> false
            }
        }

        overlayView = root
        windowManager.addView(root, params)

        serviceScope.launch {
            app.repository.voicesNewest.collectLatest { allVoices ->
                latestCards = allVoices
                renderThreeColumnGrid(gridContainer, allVoices, app, dp)
            }
        }
    }

    private fun renderThreeColumnGrid(
        grid: GridLayout,
        allCards: List<VoiceCard>,
        app: FFVoiceApp,
        dp: Float
    ) {
        grid.removeAllViews()
        val cards = if (showAllSounds) allCards else allCards.filter { it.isPinnedToOverlay }
        if (cards.isEmpty()) {
            grid.addView(TextView(this).apply {
                text = if (showAllSounds) "Add voices in app" else "No pinned voices"
                setTextColor(Color.parseColor("#FF94A3B8"))
                textSize = 11f
                setPadding(8, 12, 8, 12)
            })
            return
        }

        cards.forEach { card ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding((6 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt(), (8 * dp).toInt())
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#FF11182D"))
                    cornerRadius = 14f * dp
                    setStroke((1 * dp).toInt(), Color.parseColor("#337C3AED"))
                }
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins((3 * dp).toInt(), (3 * dp).toInt(), (3 * dp).toInt(), (3 * dp).toInt())
                }
            }

            val playSize = (44 * dp).toInt()
            val playCircle = TextView(this).apply {
                text = "▶"
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#FF06101E"))
                textSize = 14f
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.parseColor("#FF00E5FF"), Color.parseColor("#FF7C3AED"))
                ).apply {
                    shape = GradientDrawable.OVAL
                }
                layoutParams = LinearLayout.LayoutParams(playSize, playSize)
            }

            val label = TextView(this).apply {
                text = card.name
                setTextColor(Color.WHITE)
                textSize = 10f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setPadding(0, (6 * dp).toInt(), 0, 0)
            }

            cell.addView(playCircle)
            cell.addView(label)
            cell.setOnClickListener {
                app.audioPlayer.togglePlay(card)
            }
            grid.addView(cell)
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "isff_floating_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.floating_panel),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("IS FF VOICE")
            .setContentText("Floating gaming panel active")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        serviceScope.cancel()
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        overlayView = null
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 7041
    }
}
