package com.ffvoicestudio.app.media

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.support.v4.media.session.MediaSessionCompat
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat.MediaStyle
import com.ffvoicestudio.app.FFVoiceApp
import com.ffvoicestudio.app.MainActivity
import com.ffvoicestudio.app.R

/**
 * Foreground MediaPlayback Service keeping soundboard playback active while switching
 * between IS FF VOICE and Garena Free Fire on Android 11 (TECNO KG5k), with MediaStyle
 * notification controls (Pause/Resume + Stop All).
 */
class SoundboardPlaybackService : Service() {

    private var mediaSession: MediaSessionCompat? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        mediaSession = MediaSessionCompat(this, "ISFFVoiceSession").apply {
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as FFVoiceApp
        when (intent?.action) {
            ACTION_PAUSE_RESUME -> {
                if (app.audioPlayer.state.value.isAnyPlaying) {
                    app.audioPlayer.pauseAll()
                } else {
                    app.audioPlayer.resumeAll()
                }
            }
            ACTION_STOP_ALL -> {
                app.audioPlayer.stopAll()
                stopSelf()
                return START_NOT_STICKY
            }
        }

        val state = app.audioPlayer.state.value
        if (state.activeTracks.isEmpty()) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification(state))
        return START_NOT_STICKY
    }

    private fun buildNotification(state: PlaybackState): Notification {
        val primaryName = state.primaryCardId?.let { state.activeTracks[it]?.cardName }
            ?: getString(R.string.app_name)
        val countText = if (state.activeTracks.size > 1) " (+${state.activeTracks.size - 1})" else ""

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val pauseResumeIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, SoundboardPlaybackService::class.java).apply { action = ACTION_PAUSE_RESUME },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopAllIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, SoundboardPlaybackService::class.java).apply { action = ACTION_STOP_ALL },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val pauseLabel = if (state.isAnyPlaying) "Pause" else "Resume"
        val pauseIcon = if (state.isAnyPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("IS FF VOICE · $primaryName$countText")
            .setContentText(if (state.isAnyPlaying) "Playing soundboard audio" else "Soundboard paused")
            .setContentIntent(openAppIntent)
            .setOngoing(state.isAnyPlaying)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(pauseIcon, pauseLabel, pauseResumeIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop All", stopAllIntent)
            .setStyle(
                MediaStyle()
                    .setMediaSession(mediaSession?.sessionToken)
                    .setShowActionsInCompactView(0, 1)
            )
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Soundboard Playback Controls",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "isff_soundboard_playback"
        private const val NOTIFICATION_ID = 7102
        const val ACTION_PAUSE_RESUME = "com.ffvoicestudio.app.ACTION_PAUSE_RESUME"
        const val ACTION_STOP_ALL = "com.ffvoicestudio.app.ACTION_STOP_ALL"

        fun sync(context: Context, state: PlaybackState) {
            val intent = Intent(context, SoundboardPlaybackService::class.java)
            if (state.activeTracks.isEmpty()) {
                context.stopService(intent)
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }
    }
}
